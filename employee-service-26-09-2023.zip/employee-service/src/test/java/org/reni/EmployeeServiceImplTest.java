package org.reni;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.reni.entities.Employee;
import org.reni.exception.EmployeeAppException;
import org.reni.repositories.EmployeeRepository;
import org.reni.service.EmployeeService;
import org.reni.service.EmployeeServiceImpl;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class EmployeeServiceImplTest {
	
	
	private EmployeeRepository employeeRepository=mock(EmployeeRepository.class);
	
	private EmployeeService employeeService=new EmployeeServiceImpl(employeeRepository);
	
	
	
	@BeforeEach
	void init() {
		System.out.println("Init Method executed");
	}
	@AfterEach
	void clean() {
		System.out.println("Aftereach executed");
	}
	@BeforeAll
	static void setUp() {
		System.out.println("Setup method execurted");
	}
	@AfterAll
	static void tearDown() {
		System.out.println("Teardown method execuetd");
	}
	
	

	@Test
	void testGetAllEmployees() {
		System.out.println("tetGetAll exeucted");
		List<Employee> employees=new ArrayList<Employee>();
		employees.add(new Employee(1,"Kiran","Male",23,56000,"kiran@gmail.com",LocalDate.now(),"9898989898"));
		employees.add(new Employee(2,"Sara","Female",22,45000,"sara@hotmail.com",LocalDate.now(),"7878787878"));
		
		when(employeeRepository.findAll()).thenReturn(employees);
		
		var result=employeeService.getAllEmployees();
		assertNotNull(result);
		assertEquals(2, result.size());
		
		
	}
	@Test
	void testGetByIdWhenProvidedWithAValidId() {
		System.out.println("testGetById with valid id executed");
		Employee employee=new Employee(1,"Manu","Male",23,45000,"m@gmail.com",LocalDate.of(2022, 10,10),"8888888888");
		Optional<Employee> optEmployee=Optional.of(employee);
		when(employeeRepository.findById(1)).
		thenReturn(optEmployee);
		
		Employee emp=employeeService.getById(1);
		assertNotNull(employee);
		
		assertEquals("Manu", employee.getName());
		
		
		
	}
	@Test
	void testGetByIdWhenProvidedWithAnInvalidId() {
		System.out.println("Test get by id with invalid id executed");
		try {
		when(employeeRepository.findById(22)).thenThrow(EmployeeAppException.class);
		
		employeeService.getById(22);
		}
		catch(EmployeeAppException ex) {
			
		}
	}
	@Test
	void testAddEmployee() {
		
		System.out.println("Test add employee executed");
		Employee emp=new Employee(1,"Asha","Female",22,98000,"asha@gmail.com",LocalDate.now(),"9898989898");
		
		when(employeeRepository.save(emp)).thenReturn(emp);
		
		Employee emp1=employeeService.addEmployee(emp);
		
		assertNotNull(emp1);
		assertEquals("Asha", emp.getName());
		
	}
	@Test
	@Disabled
	public void testDeleteEmployee() {
		
		System.out.println("Test delete employee executed");
		
		
				
		String response=employeeService.deleteEmployee(1);
		
		assertEquals("Employee with id 1 deleted successfully", response);
		
	}
	
	

}
