package org.reni;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.ClassOrderer.OrderAnnotation;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.reni.entities.Employee;
import org.reni.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EmployeeServiceApplicationTests {
	@Autowired
	private MockMvc mockMvc;
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	
	private ObjectMapper mapper=new ObjectMapper();

	@Test
	@Order(1)
	@Disabled
	public void testGetAll() throws Exception {
		
		mockMvc.perform(get("/api/employees")).andExpect(status().isOk())
		.andExpect(jsonPath("$", Matchers.hasSize(6)));
			
	}
	@Test
	@Order(2)
	@Disabled
	public void testGetById() throws Exception {
		
		mockMvc.perform(get("/api/employees/4"))
		.andExpect(status().isOk()).andExpect(jsonPath("$.name").value("Mark"));
				
	}
	@Test
	@Order(3)
	
	public void testAddEmployee() throws Exception {
		
		Employee employee=new Employee();
		employee.setName("Shivani");
		employee.setGender("Female");
		employee.setAge(21);
		employee.setSalary(89000);
		employee.setEmail("shivani@gmail.com");
		employee.setMobile("7777777777");
		employee.setDoj(LocalDate.now());
		
		
		UsernamePasswordAuthenticationToken
			authToken=new UsernamePasswordAuthenticationToken("anna", "pass");
		
		String jwt=jwtTokenProvider.generateToken(authToken);
		System.out.println("==============="+jwt);
		
		String jsonEmployee=mapper.writeValueAsString(employee);
		
		mockMvc.perform(post("/api/employees").content(jsonEmployee)
				.contentType("application/json").header("Authorization", "Bearer "+jwt))
		.andExpect(status().isCreated()).andExpect(jsonPath("$.name").value("Shivani"));
		
		
		
	}
	@Test
	@Order(4)
	@Disabled
	public void testUpdateEmployee() throws Exception {
		
		Employee employee=new Employee();
		employee.setId(16);
		employee.setName("Sam V");
		employee.setGender("Male");
		employee.setAge(33);
		employee.setSalary(90000);
		employee.setEmail("sam@gmail.com");
		
		String json=mapper.writeValueAsString(employee);
		
		mockMvc.perform(put("/api/employees/16").content(json).contentType(MediaType.APPLICATION_JSON_VALUE))
		.andExpect(status().isOk());
		
		mockMvc.perform(get("/api/employees/16"))
		.andExpect(jsonPath("$.salary", is(90000.0)));
		
	}
	@Test
	@Disabled
	public void testGetByIdWhenProvidededWithAnInvalidId() throws Exception {
		
		mockMvc.perform(get("/api/employees/99"))
		.andExpect(status().isNotFound());
		
	}
	@Test
	@Disabled
	public void testDeleteEmployee() throws Exception {
		
		mockMvc.perform(delete("/api/employees/17"))
		.andExpect(status().isOk());
		mockMvc.perform(get("/api/employees/17"))
		.andExpect(status().isNotFound());
	}
	
	
	
	
}
