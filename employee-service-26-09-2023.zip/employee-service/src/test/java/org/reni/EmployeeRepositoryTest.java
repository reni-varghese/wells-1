package org.reni;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.reni.entities.Employee;
import org.reni.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class EmployeeRepositoryTest {
	@Autowired
	private EmployeeRepository employeeRepository;

	@Test
	void testFindBySearchTerm() {
		
		var employees=employeeRepository.findBySearchTerm("M");
		
		assertEquals(2, employees.size());
		Employee employee=employees.get(0);
		assertEquals("Mark", employee.getName());
		
		
		employees=employeeRepository.findBySearchTerm("b");
		assertNotNull(employees);
		
		
		
	}

}
