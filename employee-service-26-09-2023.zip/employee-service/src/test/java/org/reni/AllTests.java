package org.reni;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({ EmployeeRepositoryTest.class, EmployeeServiceApplicationTests.class, EmployeeServiceImplTest.class })
public class AllTests {

}
