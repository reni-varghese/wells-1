package org.reni.service;

import java.util.List;
import java.util.Optional;

import org.reni.entities.Employee;
import org.reni.exception.EmployeeAppException;
import org.reni.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeRepository employeeRepository;
	
	@Autowired
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		this.employeeRepository = employeeRepository;
	}

	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
		employeeRepository.save(employee);
		
		return employee;
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		
		
		return employeeRepository.findAll();
	}

	@Override
	public Employee getById(int id) {
		
		// TODO Auto-generated method stub
		
		return employeeRepository.findById(id)
				.orElseThrow(()->new EmployeeAppException("Employee with id "+id+" does not exist"));
	}

	@Override
	public String updateEmployee(int id, Employee employee) {
		employee.setId(id);
		employeeRepository.save(employee);
		
		return "Employee with Id "+id+" updated successfully";
	}

	@Override
	public String deleteEmployee(int id) {
		Optional<Employee> optEmployee=employeeRepository.findById(id);
		if(!optEmployee.isPresent()) {
			throw new EmployeeAppException("Employee with id "+id+" does not exist");
		}
		employeeRepository.deleteById(id);
		return "Employee with id "+id+" deleted successfully";
	}

	@Override
	public List<Employee> getEmployeeBySearchTerm(String searchTerm) {
		// TODO Auto-generated method stub
		return employeeRepository.findBySearchTerm(searchTerm);
	}
	


	
}
