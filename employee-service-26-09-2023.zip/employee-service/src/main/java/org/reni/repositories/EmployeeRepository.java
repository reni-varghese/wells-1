package org.reni.repositories;

import java.util.List;

import org.reni.entities.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;



public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	@Query("from Employee e where e.name like :search%")
	List<Employee> findBySearchTerm(@Param("search") String searchTerm);
}
