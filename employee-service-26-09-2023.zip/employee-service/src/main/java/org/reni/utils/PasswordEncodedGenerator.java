package org.reni.utils;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class PasswordEncodedGenerator {
	
	public static void main(String [] args) {
		
		PasswordEncoder encoder=new BCryptPasswordEncoder();
		System.out.println(encoder.encode("pwd"));
		System.out.println(encoder.encode("pass"));
		
	}

}
