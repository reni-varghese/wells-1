function Greet() {
  return <h1>Welcome to React JS from Greet Component</h1>;
}

export default Greet;
