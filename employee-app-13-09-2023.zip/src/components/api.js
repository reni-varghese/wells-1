import axios from "axios";

const addEmployee = async (employee) => {
  const token=localStorage.getItem("token");
  console.log("============="+token)
    const bearerToken=`Bearer ${token}`;
  console.log('Bearer token ==========='+bearerToken);
  const response = await axios.post(
    "http://localhost:8080/api/employees",
    employee,{
      headers:{
        "Authorization": `Bearer ${token}`,

      }
      }
  );
  return response.data;
  
};

const getAll = async () => {
  const response = await axios.get("http://localhost:8080/api/employees");

  return response.data;
};

const login=async (loginDetails)=>{
  const response=await axios.post("http://localhost:8080/api/auth/login",loginDetails);
  return response.data;
}

export { addEmployee, getAll,login };
