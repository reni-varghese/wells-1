import { rest } from "msw";

export const handlers = [
  // Handles a GET /user request
  rest.get("http://localhost:8080/api/employees", (req, res, ctx) => {
    return res(
      ctx.json([
        {
          id: 1,
          name: "Kiran",
          gender: "Male",
          age: 22,
          salary: 45000,
          email: "kiran@gmail.com",
          doj: "2022-10-10",
          mobile: "9999999999",
        },
        {
          id: 2,
          name: "Shilpa",
          gender: "Female",
          age: 24,
          salary: 87000,
          email: "shilpa@gmail.com",
          doj: "2021-12-12",
          mobile: "8888888888",
        },
      ])
    );
  }),
];
