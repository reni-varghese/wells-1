import { useState, useEffect } from "react";
import { deleteEmployee, findBySearch, getAll } from "./api";
import { Link, useNavigate } from "react-router-dom";
import SearchEmployee from "./SearchEmployee";

const EmployeeList = () => {
  const [employees, setEmployees] = useState([]);
  // const [originalEmployees, setOriginalEmployees] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    return async () => {
      const result = await getAll();
      console.log(result);
      setEmployees(result);
      // setOriginalEmployees(result);
    };
  }, []);

  const handleSearch = async (searchTerm) => {
    console.log(searchTerm);
    // if (searchTerm) {
    //   const newEmployees = originalEmployees.filter((emp) =>
    //     emp.name.startsWith(searchTerm)
    //   );
    //   setEmployees(newEmployees);
    // } else {
    //   setEmployees(originalEmployees);
    // }
    if (searchTerm) {
      const result = await findBySearch(searchTerm);
      setEmployees(result);
    } else {
      const result = await getAll();
      setEmployees(result);
    }
  };

  const handleDelete = async (id) => {
    const response = window.confirm(
      "Do you wish to delete employee with id " + id
    );
    if (response) {
      await deleteEmployee(id);
      const result = await getAll();
      setEmployees(result);
    }
    navigate("/list");
  };

  return (
    <div className="container">
      <h3 className="text-primary">Employee Details</h3>
      <SearchEmployee onSearch={handleSearch} />
      <table className="table table-striped table-bordered">
        <thead>
          <tr>
            <th>Employee Id</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Salary</th>
            <th>Email</th>
            <th>Date of Joining</th>
            <th>Mobile</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((employee) => (
            <tr key={employee.id}>
              <td>{employee.id}</td>
              <td>{employee.name}</td>
              <td>{employee.gender}</td>
              <td>{employee.age}</td>
              <td>{employee.salary}</td>
              <td>{employee.email}</td>
              <td>{employee.doj}</td>
              <td>{employee.mobile}</td>
              <td>
                <Link to={`/update/${employee.id}`} className="btn btn-warning">
                  Update
                </Link>{" "}
                &nbsp;&nbsp;
                <button
                  onClick={() => handleDelete(employee.id)}
                  className="btn btn-danger"
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeList;
