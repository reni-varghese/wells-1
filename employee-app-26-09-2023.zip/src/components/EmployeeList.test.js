import { render, screen, waitFor } from "@testing-library/react";
import EmployeeList from "./EmployeeList";
import { MemoryRouter } from "react-router-dom";

test("Render Employee List Component", () => {
  render(
    <MemoryRouter>
      <EmployeeList />
    </MemoryRouter>
  );

  const text = screen.getByText("Employee Details");
  expect(text).toBeInTheDocument();
});

test("Render rows from the database", async () => {
  render(
    <MemoryRouter>
      <EmployeeList />
    </MemoryRouter>
  );
  await waitFor(() => {
    setTimeout(async () => {
      const rows = await screen.findAllByRole("row");
      expect(rows).toHaveLength(3);
    }, 1000);
  });
});
