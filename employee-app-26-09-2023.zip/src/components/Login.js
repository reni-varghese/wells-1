import {useState} from 'react'
import {login} from "./api";
const Login = () => {
  const [usernameOrEmail,setUsernameOrEmail]=useState('');
  const [password, setPassword] = useState('')
  const [loginStatus, setLoginStatus] = useState('')

  const handleUsernameChange=(e)=>{
    setUsernameOrEmail(e.target.value);
  }
  const handlePasswordChange=(e)=>{
    setPassword(e.target.value);
  }

  const handleSubmit=async (e)=>{
    e.preventDefault();
    const loginDetails={
      usernameOrEmail,
      password
    }
    try{
      const result=await login(loginDetails);
      console.log(result.accessToken);
      setLoginStatus("User Logged in Successfully");
      localStorage.setItem("token",result.accessToken);
    }
    catch(error){
      console.log(error);
      if(error.response.status===401){}
      setLoginStatus("Invalid User Credentials, please try again")
    }


  }

  return (
    <div className="container">

      <form className="col-4" onSubmit={handleSubmit}>
        <div>
          <label>User Name</label>
          <input type="text" className="form-control" onChange={handleUsernameChange} />
        </div>
        <div>
          <label>User Name</label>
          <input type="password" className="form-control" onChange={handlePasswordChange}/>
        </div>
        <br />
        <button className="btn btn-success">Login</button>
      </form>
      <span>{loginStatus}</span>
    </div>
  );
};

export default Login;
