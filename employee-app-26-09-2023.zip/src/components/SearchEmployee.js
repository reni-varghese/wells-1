const SearchEmployee = ({ onSearch }) => {
  const handleSearchChange = (e) => {
    onSearch(e.target.value);
  };

  return (
    <div className="col-4">
      <input
        type="text"
        className="form-control"
        placeholder="Search By Name"
        onChange={handleSearchChange}
      />
    </div>
  );
};

export default SearchEmployee;
