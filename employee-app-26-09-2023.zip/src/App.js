import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import AddEmployee from "./components/AddEmployee";
import EmployeeList from "./components/EmployeeList";
import RootLayout from "./components/RootLayout";
import Login from "./components/Login";
import UpdateEmployee from "./components/UpdateEmployee";

const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    children: [
      { path: "/", element: <Login /> },
      { path: "/list", element: <EmployeeList /> },
      { path: "/add", element: <AddEmployee /> },
      {path:"/update/:id",element:<UpdateEmployee/>}
    ],
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
