import axios from "axios";

const addEmployee = async (employee) => {
  const token=localStorage.getItem("token");
  console.log("============="+token)
    const bearerToken=`Bearer ${token}`;
  console.log('Bearer token ==========='+bearerToken);
  const response = await axios.post(
    "http://localhost:8080/api/employees",
    employee,{
      headers:{
        "Authorization": `Bearer ${token}`,

      }
      }
  );
  return response.data;

};

const getAll = async () => {
  const response = await axios.get("http://localhost:8080/api/employees");

  return response.data;
};

const login=async (loginDetails)=>{
  const response=await axios.post("http://localhost:8080/api/auth/login",loginDetails);
  return response.data;
}

const getById=async(id)=>{
   const response= await axios.get(`http://localhost:8080/api/employees/${id}`)
    return response.data;
}
const updateEmployee=async (id,employee)=>{
    const response=await axios.put(`http://localhost:8080/api/employees/${id}`,employee);
    return response.data;
}

const deleteEmployee=async (id)=>{
    const response= await axios.delete(`http://localhost:8080/api/employees/${id}`)
    return response.data
}

export { addEmployee, getAll,login,getById,updateEmployee,deleteEmployee };
