import {useEffect, useState} from "react";
import {useNavigate, useParams} from "react-router-dom";
import {getById, updateEmployee} from "./api";
const UpdateEmployee=() => {
    const [name, setName] = useState("");
    const [age, setAge] = useState("");
    const [gender, setGender] = useState("");
    const [salary, setSalary] = useState("");
    const [email, setEmail] = useState("");
    const [doj, setDoj] = useState("");
    const [mobile, setMobile] = useState("");
    const navigate = useNavigate();

    const params=useParams();

    useEffect(() => {
        return async ()=>{
            const employee=await getById(params.id);
           setName(employee.name);
           setGender(employee.gender);
           setAge(employee.age);
           setSalary(employee.salary);
           setEmail(employee.email);
           setDoj(employee.doj);
           setMobile(employee.mobile);

        }
    }, []);

    const handleNameChange = (e) => {
        setName(e.target.value);
    };
    const handleGenderChange = (e) => {
        setGender(e.target.value);
    };
    const handleAgeChange = (e) => {
        setAge(e.target.value);
    };
    const handleSalaryChange = (e) => {
        setSalary(e.target.value);
    };
    const handleEmailChange = (e) => {
        setEmail(e.target.value);
    };
    const handleDojChange = (e) => {
        setDoj(e.target.value);
    };

    function handleMobileChange(e) {
        setMobile(e.target.value);
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        const employee = {
            name: name,
            gender: gender,
            age: age,
            salary: salary,
            email: email,
            doj: doj,
            mobile: mobile,
            };
            await updateEmployee(params.id,employee);
            navigate("/list")
        };

        return (
            <div className="container">
                <h3 className="text-sucess">Update Employee</h3>
                <form className="col-4" onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label className="form-label">Name</label>
                        <input
                            type="text"
                            className="form-control" value={name}
                            onChange={handleNameChange}
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Gender</label>
                        &nbsp;&nbsp;
                        <div className="form-check-inline">
                            <input
                                type="radio"
                                name="gender"
                                value="Male"
                                className="form-check-input"
                                onChange={handleGenderChange}
                                checked={gender==='Male'}
                            />
                            <label className="form-check-label">Male</label>
                        </div>
                        &nbsp;&nbsp;
                        <div className="form-check-inline">
                            <input
                                type="radio"
                                name="gender"
                                value="Female"
                                className="form-check-input"
                                onChange={handleGenderChange}
                                checked={gender==='Female'}
                            />
                            <label className="form-check-label">Female</label>
                        </div>
                    </div>
                    <div className="form-group">
                        <label className="form-label">Age</label>
                        <input
                            type="text"
                            className="form-control"
                            onChange={handleAgeChange} value={age}
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Salary</label>
                        <input
                            type="text"
                            className="form-control"
                            onChange={handleSalaryChange} value={salary}
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Email</label>
                        <input
                            type="email"
                            className="form-control"
                            onChange={handleEmailChange} value={email}
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Date of Joining</label>
                        <input
                            type="date"
                            className="form-control"
                            onChange={handleDojChange} value={doj}
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Mobile Number</label>
                        <input
                            type="text"
                            className="form-control"
                            onChange={handleMobileChange} value={mobile}
                        />
                    </div>
                    <br/>
                    <button className="btn btn-success">Update Employee</button>
                </form>
            </div>
        );
    };

export default UpdateEmployee;
