import { useState, useEffect } from "react";
import {deleteEmployee, getAll} from "./api";
import {Link, useNavigate} from "react-router-dom";

const EmployeeList = () => {
  const [employees, setEmployees] = useState([]);
  const navigate=useNavigate();

  useEffect(() => {
    return async () => {
      const result = await getAll();
      setEmployees(result);
    };
  },[]);

 const handleDelete=async (id)=>{
   const response=window.confirm("Do you wish to delete employee with id "+id);
   if(response){
     await deleteEmployee(id);
     const result=await getAll();
     setEmployees(result);


   }
   navigate("/list")

 }

  return (
    <div className="container">
      <h3 className="text-primary">Employee Details</h3>
      <table className="table table-striped table-bordered">
        <thead>
          <tr>
            <th>Employee Id</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Salary</th>
            <th>Email</th>
            <th>Date of Joining</th>
            <th>Mobile</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((employee) => (
            <tr key={employee.id}>
              <td>{employee.id}</td>
              <td>{employee.name}</td>
              <td>{employee.gender}</td>
              <td>{employee.age}</td>
              <td>{employee.salary}</td>
              <td>{employee.email}</td>
              <td>{employee.doj}</td>
              <td>{employee.mobile}</td>
              <td>
                <Link to={`/update/${employee.id}`} className="btn btn-warning">Update</Link> &nbsp;&nbsp;
                <button onClick={()=>handleDelete(employee.id)} className="btn btn-danger">Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeList;
