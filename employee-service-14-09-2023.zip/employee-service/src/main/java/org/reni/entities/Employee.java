package org.reni.entities;

import java.time.LocalDate;

import org.springframework.stereotype.Service;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="employees")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(nullable = false)
	@NotEmpty
	private String name;
	@Pattern(regexp = "(Male|Female)",message = "Gender should be either Male or Female")
	private String gender;
	@Min(value = 18, message = "Age should be between 18 and 60")
	@Max(value = 60,message = "Age should be between 18 and 60")
	private int age;
	private double salary;
	@Column(nullable = false,unique = true)
	@Email(message = "Invalid Email Id")
	private String email;
	private LocalDate doj;
	@Pattern(regexp="^[9876][0-9]{9}$",message = "Mobile number should contain 10 digits")
	private String mobile;
	
	
}
