package org.reni.service;

import java.util.List;

import org.reni.entities.Employee;

public interface EmployeeService {

	Employee addEmployee(Employee employee);
	List<Employee> getAllEmployees();
	Employee getById(int id);
	String updateEmployee(int id,Employee employee);
	String deleteEmployee(int id);
}
