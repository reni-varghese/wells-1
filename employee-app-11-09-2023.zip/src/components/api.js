import axios from "axios";

const addEmployee = async (employee) => {
  const response = await axios.post(
    "http://localhost:8080/api/employees",
    employee
  );
  return response.data;
};

const getAll = async () => {
  const response = await axios.get("http://localhost:8080/api/employees");

  return response.data;
};

export { addEmployee, getAll };
