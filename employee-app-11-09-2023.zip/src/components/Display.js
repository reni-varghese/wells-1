const Display = () => {
  return (
    <div>
      <h1>Hello from Display</h1>
    </div>
  );
};

export default Display;
